import requests
import json
import datetime
import time

import yaml

from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError







##### SLACK 토큰 #####
with open('config.yaml', encoding='UTF-8') as f:
    _cfg = yaml.load(f, Loader=yaml.FullLoader)
SLACK_WEBHOOK_URL = _cfg['SLACK_WEBHOOK_URL']
SLACK_BOT_TOKEN = _cfg['SLACK_BOT_TOKEN']
SLACK_BOT_CHANNEL = _cfg['SLACK_BOT_CHANNEL']






##### SLACK으로 메세지 보내는 함수 #####
def send_message_slack(msg):
    """슬랙 메세지 전송"""
    now = datetime.datetime.now()
    message = f"[{now.strftime('%Y-%m-%d %H:%M:%S')}] {str(msg)}"
    client = WebClient(token=SLACK_BOT_TOKEN)

    try:
        response = client.chat_postMessage(channel=SLACK_BOT_CHANNEL, text=message)
        print("Message sent: ", response["ts"])
    except SlackApiError as e:
        print("Error sending message: {}".format(e))