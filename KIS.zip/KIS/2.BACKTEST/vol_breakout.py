import os, sqlite3
import pandas as pd
import numpy as np
from datetime import datetime

from scipy.stats import skew, kurtosis
import statsmodels.api as sm








##### DB 불러오기 #####

# 현재 절대경로 확인
abspath = os.path.abspath('/API/KIS/')

# SQLite3 DB 경로 지정
DB_DIR = os.path.join(abspath, "1.DB")
STOCK_DB_FILE = 'stockdb.sqlite3'
DB_PATH = os.path.join(DB_DIR, STOCK_DB_FILE)

# DB 읽기
conn = sqlite3.connect(DB_PATH)
kr_stock_close_px = pd.read_sql_query('SELECT * FROM "kr_stock_close_px"', conn, index_col='date')
kr_stock_open_px = pd.read_sql_query('SELECT * FROM "kr_stock_open_px"', conn, index_col='date')
kr_stock_high_px = pd.read_sql_query('SELECT * FROM "kr_stock_high_px"', conn, index_col='date')
kr_stock_low_px = pd.read_sql_query('SELECT * FROM "kr_stock_low_px"', conn, index_col='date')
kr_stock_avg_px = pd.read_sql_query('SELECT * FROM "kr_stock_avg_px"', conn, index_col='date')
kr_stock_volume = pd.read_sql_query('SELECT * FROM "kr_stock_volume"', conn, index_col='date')
conn.close()






##### 데이터 전처리 #####
kr_stock_tickers = kr_stock_close_px.columns.tolist()

kr_stock_close_px = kr_stock_close_px.fillna(method='bfill')
kr_stock_open_px = kr_stock_open_px.fillna(method='bfill')
kr_stock_high_px = kr_stock_high_px.fillna(method='bfill')
kr_stock_low_px = kr_stock_low_px.fillna(method='bfill')
kr_stock_range_px = kr_stock_high_px - kr_stock_low_px

kr_stock_close_px.columns = pd.MultiIndex.from_tuples([(col_name, new_col_name) for col_name in kr_stock_close_px.columns for new_col_name in ['Close']])
kr_stock_open_px.columns = pd.MultiIndex.from_tuples([(col_name, new_col_name) for col_name in kr_stock_open_px.columns for new_col_name in ['Open']])
kr_stock_high_px.columns = pd.MultiIndex.from_tuples([(col_name, new_col_name) for col_name in kr_stock_high_px.columns for new_col_name in ['High']])
kr_stock_low_px.columns = pd.MultiIndex.from_tuples([(col_name, new_col_name) for col_name in kr_stock_low_px.columns for new_col_name in ['Low']])
kr_stock_range_px.columns = pd.MultiIndex.from_tuples([(col_name, new_col_name) for col_name in kr_stock_range_px.columns for new_col_name in ['Range']])

kr_stock_px = pd.concat([kr_stock_close_px, kr_stock_open_px, kr_stock_high_px, kr_stock_low_px, kr_stock_range_px], axis=1)
kr_stock_px.sort_index(axis=1, level=[0,1], inplace=True)

print("인풋 데이터 확인")
print("---------- ---------- ----------")
print("삼성전자 시가 데이터:", kr_stock_px['005930 KR Equity']['Open'].tail())
print("삼성전자 저가 데이터:", kr_stock_px['005930 KR Equity']['Low'].tail())
print("삼성전자 고가 데이터:", kr_stock_px['005930 KR Equity']['High'].tail())
print("삼성전자 종가 데이터:", kr_stock_px['005930 KR Equity']['Close'].tail())
print("삼성전자 변동폭 데이터:", kr_stock_px['005930 KR Equity']['Range'].tail())
print("---------- ---------- ----------")






##### 전략 세팅 #####
# 1) 전일의 고저 변동폭 계산
# 2) 당일의 목표가 계산
# 3) 당일에 목표가를 상향돌파할 경우 진입
# 4) 익일 시가에 청산

def vol_breakout_strategy(k, df_raw, ticker, initial_balance, cost, start, end):
    # 테스트 기간 설정
    df = df_raw.loc[start:end].copy()
    # 변동폭
    prv_d_vol_target = df[ticker]['Range'].shift(1) * k
    # 목표가
    df.loc[df.index, (ticker, 'Target')] = df[ticker]['Open'] + prv_d_vol_target
    # 매수
    df.loc[df.index, (ticker, 'Signal')] = np.where(df[ticker]['High'] > df[ticker]['Target'], 1, 0)
    df.loc[df.index, (ticker, 'Buy')] = np.where(df[ticker]['High'] > df[ticker]['Target'], df[ticker]['Target'], 0)
    df.loc[df.index, (ticker, 'Sell')] = np.where(df[ticker]['High'] > df[ticker]['Target'], df[ticker]['Close'], 0)
    df.loc[df.index, (ticker, 'Pure Daily Return')] = np.where(df[ticker]['High'] > df[ticker]['Target'],
                                                          df[ticker]['Close'] / df[ticker]['Target'] - 1, 0)
    df.loc[df.index, (ticker, 'Real Daily Return')] = np.where(df[ticker]['Signal'] == 1,
                                                               df[ticker]['Pure Daily Return'] - (cost / 10000) * 2,
                                                               df[ticker]['Pure Daily Return'])
    df.loc[df.index, (ticker, 'Daily Balance')] = initial_balance * (1 + df[ticker]['Real Daily Return']).cumprod()
    df.loc[df.index, (ticker, 'Total Return')] = (1 + df[ticker]['Real Daily Return']).cumprod()
    df.loc[df.index, (ticker, 'Total Trading')] = df[ticker]['Signal'].cumsum()
    TRADING = df[ticker]['Total Trading'].iloc[-1]
    # 수익률
    df.index = pd.to_datetime(df.index)
    N = (df.index[-1] - df.index[0]).days
    init_balance = float(initial_balance)
    last_balance = df[ticker]['Daily Balance'].iloc[-1].astype(float)
    TOTAL = round((last_balance / init_balance - 1) * 100, 2)
    CAGR = round(((last_balance / init_balance) ** (365 / N) - 1) * 100, 2)
    # MDD 계산
    array_tr = np.array(df[ticker]['Total Return'])
    dd_list = -(np.maximum.accumulate(array_tr) - array_tr) / np.maximum.accumulate(array_tr)
    peak_lower = np.argmax(np.maximum.accumulate(array_tr) - array_tr)
    peak_upper = np.argmax(array_tr[:peak_lower])
    MDD = round((array_tr[peak_lower] - array_tr[peak_upper]) / array_tr[peak_upper] * 100, 2)

    return N, TRADING,\
            TOTAL, CAGR, MDD,\
            df[ticker][['Target', 'Open', 'Close', 'Signal', 'Pure Daily Return', 'Real Daily Return', 'Daily Balance']], df[ticker]['Daily Balance']





##### 전략 테스트 #####
df_raw = kr_stock_px
ticker = '005930 KR Equity'
k = 0.5
initial_balance = 100000000
cost = 10
start = '2001-01-01'
end = '2023-03-31'

test_total_period = vol_breakout_strategy(k, df_raw, ticker, initial_balance, cost, start, end)[0]
test_total_trading = vol_breakout_strategy(k, df_raw, ticker, initial_balance, cost, start, end)[1]
test_total_return = vol_breakout_strategy(k, df_raw, ticker, initial_balance, cost, start, end)[2]
test_annual_return = vol_breakout_strategy(k, df_raw, ticker, initial_balance, cost, start, end)[3]
test_total_mdd = vol_breakout_strategy(k, df_raw, ticker, initial_balance, cost, start, end)[4]
test_result = vol_breakout_strategy(k, df_raw, ticker, initial_balance, cost, start, end)[5]
test_graph = vol_breakout_strategy(k, df_raw, ticker, initial_balance, cost, start, end)[6]





##### 전략 테스트 결과 #####
print("전략 테스트 기간 ", test_total_period ,"영업일 동안")
print("전략 테스트 트레이딩 ", test_total_trading ,"번 매수/매도")
print("---------- ---------- ----------")
print("전략 테스트 결과(1) - 누적 수익률: ", test_total_return ,"%")
print("전략 테스트 결과(2) - 연간 수익률: ", test_annual_return ,"%")
print("전략 테스트 결과(3) - MDD: ", test_total_mdd ,"%")
print("전략 테스트 결과(4) - 트레이딩 현황: \n", test_result.to_string())
print("전략 테스트 결과(5) - 수익률 추이")

import matplotlib.pyplot as plt
from matplotlib import font_manager, rc
font_path = "C:\Windows\Fonts\HMFMPYUN.TTF"
font = font_manager.FontProperties(fname=font_path).get_name()
rc('font', family=font)

plt.plot(test_graph.index, test_graph.values)
plt.title('변동성 돌파 전략 수익 추이')
plt.xlabel('Date')
plt.ylabel('잔고')
plt.show()










