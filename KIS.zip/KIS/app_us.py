import requests
import json
import datetime
import time
import pandas as pd

import yaml

import sys
sys.path.append('5.UTILITY')
from message_slack import *

import pykis





##### KIS API 정보 #####
with open('config.yaml', encoding='UTF-8') as f:
    _cfg = yaml.load(f, Loader=yaml.FullLoader)
REAL_APP_KEY = _cfg['REAL_APP_KEY']
REAL_APP_SECRET = _cfg['REAL_APP_SECRET']
TEST_APP_KEY = _cfg['TEST_APP_KEY']
TEST_APP_SECRET = _cfg['TEST_APP_SECRET']
REAL_CANO = _cfg['REAL_CANO']
TEST_CANO = _cfg['TEST_CANO']
REAL_ACNT_PRDT_CD = _cfg['REAL_ACNT_PRDT_CD']
TEST_ACNT_PRDT_CD = _cfg['TEST_ACNT_PRDT_CD']

SLACK_WEBHOOK_URL = _cfg['SLACK_WEBHOOK_URL']
SLACK_BOT_TOKEN = _cfg['SLACK_BOT_TOKEN']
SLACK_BOT_CHANNEL = _cfg['SLACK_BOT_CHANNEL']






##### API에 접속하기 위한 필수 정보를 JSON INPUT으로 변형 #####

# (1) API KEY
key_info = {
	"appkey": TEST_APP_KEY,
	"appsecret": TEST_APP_SECRET
}

# (2) 계좌 정보
account_info = {	# 사용할 계좌 정보
	"account_code": TEST_CANO,
	"product_code": TEST_ACNT_PRDT_CD
}

# (3) 접속할 환경 정보
domain_info = pykis.DomainInfo(kind="virtual")
# domain_info = pykis.DomainInfo(kind="real")






#### API 객체 생성 #####
api = pykis.Api(key_info=key_info, domain_info=domain_info, account_info=account_info)


# 계좌 현금 조회
acc_cash_dict = api.get_kr_acc_balance()
국내계좌_예수금 = acc_cash_dict['예수금'][0]
국내계좌_평가금 = acc_cash_dict['평가금'][0]
국내계좌_손익 = acc_cash_dict['손익'][0]
국내계좌_매수가능금액 = api.get_kr_buyable_cash()
print(f'예수금: {국내계좌_예수금}원 | 평가금: {국내계좌_평가금}원 | 손익: {국내계좌_손익}원 | 매수가능 금액: {국내계좌_매수가능금액}원')
send_message_slack("===국내계좌 조회 프로그램 테스트입니다===")
send_message_slack(f"현재 국내계좌 예수금은 {국내계좌_예수금} (원) 입니다")
send_message_slack(f"현재 국내계좌 평가금액은 {국내계좌_평가금} (원) 입니다")
send_message_slack(f"현재 국내계좌 손익은 {국내계좌_손익} (원) 입니다")
send_message_slack(f"현재 국내계좌로 매수가능한 금액은 {국내계좌_매수가능금액} (원) 입니다")


# 계좌 주식(국내) 조회
acc_stock_dict = api.get_kr_stock_balance()
if acc_stock_dict.empty:
	print("현재 보유한 주식이 없습니다")
	send_message_slack("===국내계좌 잔고 조회 프로그램 테스트입니다===")
	send_message_slack("===현재 보유한 주식이 없습니다===")
else:
	acc_stock_dict = acc_stock_dict.set_index('종목코드')
	print("===국내계좌 잔고 조회 프로그램 테스트입니다===")
	print(acc_stock_dict)
	국내계좌_종목티커 = acc_stock_dict.index.tolist()
	국내계좌_종목명 = acc_stock_dict['종목명']
	국내계좌_보유수량 = acc_stock_dict['보유수량']
	국내계좌_매입단가 = acc_stock_dict['매입단가']
	국내계좌_현재가 = acc_stock_dict['현재가']
	국내계좌_수익률 = acc_stock_dict['수익률']
	send_message_slack("===국내계좌 잔고 조회 프로그램 테스트입니다===")






##### 현재 시장 정보 #####

# # 환율 조회
# fx_dict = api.get_exchange_rate()
# fx_df = pd.DataFrame(fx_dict)
# print('===현재 고시 환율입니다===')
# print(fx_df)
# send_message_slack('===현재 고시 환율입니다===')
# send_message_slack(f"현재 환율은 {fx_df} 입니다")


# 테스트 종목 조회 - 국내
ticker = "005930"   # 삼성전자 종목코드
time_unit = "D"     # 기간 분류 코드 (D/day-일, W/week-주, M/month-월), 기본값 "D"
국내종목_현재가 = api.get_kr_current_price(ticker)
국내종목_거래현황 = api.get_kr_ohlcv(ticker, time_unit)
send_message_slack("===국내주식 자동매매 프로그램 테스트입니다===")
send_message_slack(f"현재 삼성전자의 가격은 {국내종목_현재가} (원) 입니다")
send_message_slack(f"최근 삼성전자의 가격과 거래 현황도 함께 보여드리겠습니다 \n{국내종목_거래현황}")


# 테스트 종목 조회 - 해외
ticker = "TSLA"
market_code = "NAS"
date_start = "20230101"
date_end = "20230427"
time_unit = "D"

해외종목_현재가 = api.get_os_current_price(ticker, market_code)
해외종목_거래현황 = api.get_os_ohlcv(ticker, market_code, date_start, date_end)
send_message_slack("===해외주식 자동매매 프로그램 테스트입니다===")
send_message_slack(f"현재 테슬라의 가격은 {해외종목_현재가} (달러) 입니다")
send_message_slack(f"최근 테슬라의 가격과 거래 현황도 함께 보여드리겠습니다 \n{해외종목_거래현황}")

