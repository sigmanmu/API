import requests
import json
import datetime
import time

import yaml

import sys
sys.path.append('5.UTILITY')
from message_slack import *

import pykis





##### KIS API 정보 #####
with open('config.yaml', encoding='UTF-8') as f:
    _cfg = yaml.load(f, Loader=yaml.FullLoader)
REAL_APP_KEY = _cfg['REAL_APP_KEY']
REAL_APP_SECRET = _cfg['REAL_APP_SECRET']
TEST_APP_KEY = _cfg['TEST_APP_KEY']
TEST_APP_SECRET = _cfg['TEST_APP_SECRET']
REAL_CANO = _cfg['REAL_CANO']
TEST_CANO = _cfg['TEST_CANO']
REAL_ACNT_PRDT_CD = _cfg['REAL_ACNT_PRDT_CD']
TEST_ACNT_PRDT_CD = _cfg['TEST_ACNT_PRDT_CD']

SLACK_WEBHOOK_URL = _cfg['SLACK_WEBHOOK_URL']
SLACK_BOT_TOKEN = _cfg['SLACK_BOT_TOKEN']
SLACK_BOT_CHANNEL = _cfg['SLACK_BOT_CHANNEL']






##### API에 접속하기 위한 필수 정보를 JSON INPUT으로 변형 #####

# (1) API KEY
key_info = {
	"appkey": TEST_APP_KEY,
	"appsecret": TEST_APP_SECRET
}

# (2) 계좌 정보
account_info = {	# 사용할 계좌 정보
	"account_code": TEST_CANO,
	"product_code": TEST_ACNT_PRDT_CD
}

# (3) 접속할 환경 정보
domain_info = pykis.DomainInfo(kind="virtual")
# domain_info = pykis.DomainInfo(kind="real")






#### API 객체 생성 #####
api = pykis.Api(key_info=key_info, domain_info=domain_info, account_info=account_info)


# 계좌 현금 조회
acc_cash_dict = api.get_kr_acc_balance()
예수금 = acc_cash_dict['예수금'][0]
평가금 = acc_cash_dict['평가금'][0]
손익 = acc_cash_dict['손익'][0]
매수가능금액 = api.get_kr_buyable_cash()
print(f'예수금: {예수금}원 | 평가금: {평가금}원 | 손익: {손익}원 | 매수가능 금액: {매수가능금액}원')
send_message_slack("===계좌 조회 프로그램 테스트입니다===")
send_message_slack(f"현재 계좌 예수금은 {예수금} (원) 입니다")
send_message_slack(f"현재 계좌 평가금액은 {평가금} (원) 입니다")
send_message_slack(f"현재 계좌 손익은 {손익} (원) 입니다")
send_message_slack(f"현재 계좌로 매수가능한 금액은 {매수가능금액} (원) 입니다")


# 계좌 주식(국내) 조회
acc_stock_dict = api.get_kr_stock_balance()
if acc_stock_dict.empty:
	print("현재 보유한 주식이 없습니다")
	send_message_slack("===계좌 잔고 조회 프로그램 테스트입니다===")
	send_message_slack("===현재 보유한 주식이 없습니다===")
else:
	acc_stock_dict = acc_stock_dict.set_index('종목코드')
	print("===계좌 잔고 조회 프로그램 테스트입니다===")
	print(acc_stock_dict)
	종목티커 = acc_stock_dict.index.tolist()
	종목명 = acc_stock_dict['종목명']
	보유수량 = acc_stock_dict['보유수량']
	매입단가 = acc_stock_dict['매입단가']
	현재가 = acc_stock_dict['현재가']
	수익률 = acc_stock_dict['수익률']
	send_message_slack("===계좌 잔고 조회 프로그램 테스트입니다===")








##### 현재 시장 정보 #####

# 환율 조회
fx_dict = api.get_exchange_rate()
fx_df = pd.DataFrame(fx_dict)
print('===현재 고시 환율입니다===')
print(fx_df)
send_message_slack('===현재 고시 환율입니다===')
send_message_slack(f"현재 환율은 {fx_df} 입니다")


# 테스트 종목 조회 - 국내
ticker = "005930"   # 삼성전자 종목코드
time_unit = "D"     # 기간 분류 코드 (D/day-일, W/week-주, M/month-월), 기본값 "D"
종목_현재가 = api.get_kr_current_price(ticker)
종목_거래현황 = api.get_kr_ohlcv(ticker, time_unit)
send_message_slack("===주식 자동매매 프로그램 테스트입니다===")
send_message_slack(f"현재 삼성전자의 가격은 {종목_현재가} (원) 입니다")
send_message_slack(f"최근 삼성전자의 가격과 거래 현황도 함께 보여드리겠습니다 \n{종목_거래현황}")









##### 변동성 돌파 전략 수립 #####

# 매수 희망 종목 리스트
symbol_list = ["005930", "373220", "207940", "005380", "035720", "066570" \
			   "247540", "009150", "010130", "352820", "036570"]
symbol_name = ["삼성전자", "LG에너지솔루션", "삼성바이오로직스", "현대차", "카카오", "LG전자" \
			   "에코프로비엠", "삼성전기", "고려야연", "하이브", "엔씨소프트"]

# 매수 전략 변수
target_buy_count = 10  # 매수할 종목 수
buy_percent = 0.1  # 종목당 매수 금액 비율

# 변동성 돌파 변수
k = 0.5







##### 변동성 돌파 전략 시작 #####
try:

	# 매수 완료된 종목 리스트
	bought_list = []
	acc_stock_dict = api.get_kr_stock_balance()
	for sym in acc_stock_dict.keys():
		bought_list.append(sym)

	# 종목별 주문 금액 계산
	매수가능금액 = api.get_kr_buyable_cash()
	buy_amount = 매수가능금액 * buy_percent
	soldout = False

	print("===변동성 돌파 전략을 시작합니다===")
	send_message_slack("===변동성 돌파 전략을 시작합니다===")
	while True:
		t_now = datetime.datetime.now()
		t_9 = t_now.replace(hour=9, minute=0, second=0, microsecond=0)
		t_start = t_now.replace(hour=9, minute=5, second=0, microsecond=0)
		t_sell = t_now.replace(hour=15, minute=15, second=0, microsecond=0)
		t_exit = t_now.replace(hour=15, minute=20, second=0, microsecond=0)
		today = datetime.datetime.today().weekday()
		# 토요일이나 일요일이면 자동 종료
		if today == 5 or today == 6:
			print("===주말이므로 프로그램을 종료합니다===")
			send_message_slack("===주말이므로 프로그램을 종료합니다===")
			break
		# 전일 미청산 종목 청산 - 잔여 수량 매도
		if t_9 < t_now < t_start and soldout == False:
			print("===전일 미청산 종목을 매도 합니다===")
			send_message_slack("===전일 미청산 종목을 매도 합니다===")
			for sym, qty in acc_stock_dict.items():
				api.sell_kr_stock(sym, qty, target_price=0)
			soldout = True
			bought_list = []
			acc_stock_dict = api.get_kr_stock_balance()
		# AM 09:05 ~ PM 03:15 : 매수
		if t_start < t_now < t_sell :
			for sym in symbol_list:
				# 매수 대상
				if len(bought_list) < target_buy_count:
					if sym in bought_list:
						continue
					last_price_info = api.get_kr_ohlcv(sym)
					last_price_open = last_price_info['Open'][0]
					last_price_high = last_price_info['High'][0]
					last_price_low = last_price_info['Low'][0]
					target_price = last_price_open + (last_price_high - last_price_low) * k
					current_price = api.get_kr_current_price(sym)
					# 매수 조건 -> 매수
					if target_price < current_price:
						buy_qty = 0  # 매수할 수량 초기화
						buy_qty = int(buy_amount // current_price)
						if buy_qty > 0:
							send_message_slack(f"==={sym} 목표가 달성({target_price} < {current_price}) 매수를 시도합니다===")
							result = api.buy_kr_stock(sym, buy_qty, target_price=0)
							if result:
								soldout = False
								bought_list.append(sym)
								acc_stock_dict = api.get_kr_stock_balance()
					time.sleep(1)
				time.sleep(1)
				# 매수 결과
				if t_now.minute == 30 and t_now.second <= 5:
					acc_stock_dict = api.get_kr_stock_balance()
					time.sleep(5)
			# PM 03:15 ~ PM 03:20 : 일괄 매도
			if t_sell < t_now < t_exit:
				if soldout == False:
					acc_stock_dict = api.get_kr_stock_balance()
					for sym in acc_stock_dict.index:
						for qty in acc_stock_dict['보유수량'][sym]:
							api.sell_kr_stock(sym, qty, target_price=0)
							soldout = True
							bought_list = []
							time.sleep(1)
			# PM 03:20 ~ : 프로그램 종료
			if t_exit < t_now:
				send_message_slack("===프로그램을 종료합니다===")
				break

except Exception as e:
    send_message_slack(f"[오류 발생]{e}")
    time.sleep(1)




